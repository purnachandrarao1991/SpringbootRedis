package com.example.redisDemo.controller;

import com.example.redisDemo.dto.Student;
import com.example.redisDemo.service.StudentProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("redis")
public class StudentController {

    @Autowired
    private StudentProducer studentProducer;

    @PostMapping("/publish")
    public ResponseEntity<String> sendMessage(@RequestBody Student student) {
        studentProducer.sendMessage(student);
        return new ResponseEntity<>("Message sent successfully vai REDIS", HttpStatus.OK);
    }
}