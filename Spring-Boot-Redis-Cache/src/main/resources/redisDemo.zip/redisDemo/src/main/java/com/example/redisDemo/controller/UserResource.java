package com.example.redisDemo.controller;// Java program to implement a
// controller

import com.example.redisDemo.dto.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("kafka")
public class UserResource {

	@Autowired
	private KafkaTemplate<String, Student>
		kafkaTemplate;

	private static final String TOPIC
		= "studentTopic";

	@PostMapping("/publish")

	public String post(@RequestBody Student student)
	{
		kafkaTemplate.send(
			TOPIC, student);

		return "Published successfully vai KAFKA";
	}
}
