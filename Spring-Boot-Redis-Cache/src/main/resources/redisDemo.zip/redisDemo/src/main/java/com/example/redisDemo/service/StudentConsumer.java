package com.example.redisDemo.service;

import com.example.redisDemo.dto.Student;
import org.springframework.stereotype.Component;


@Component
public class StudentConsumer {

    public void handleMessage(Student student) {
        System.out.println("Redis New Consumer> " + student);
    }
}