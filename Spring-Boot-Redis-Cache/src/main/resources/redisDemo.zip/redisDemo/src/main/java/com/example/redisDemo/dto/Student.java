package com.example.redisDemo.dto;

import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    private Integer id;
    private String name;
   // @JsonSerialize(using = LocalDateSerializer.class)
   // @JsonFormat(pattern = "dd/MM/yyyy")
    private String lastname;
}