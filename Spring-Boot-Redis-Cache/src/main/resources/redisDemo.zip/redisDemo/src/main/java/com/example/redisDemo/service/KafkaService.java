package com.example.redisDemo.service;

import com.example.redisDemo.dto.Student;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaService {

	// Annotation required to listen
	// the message from Kafka server
	@KafkaListener(topics = "studentTopic",
				groupId = "id", containerFactory
								= "studentListner")
	public void
	publish(Student student)
	{
		System.out.println("KAFKA New Entry: "
						+ student);
	}
}
